# Delivr, the Open Source Sendgrid Alternative

Delivr is an open source mailing engine that aims to let you send email without worrying about anything under the hood. Create projects, send email without having to warm up IP addresses, and more.

We're in early alpha, but check back soon for updates!
